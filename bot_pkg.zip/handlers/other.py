from aiogram import types, Dispatcher
from create_bot import dp, bot

"""Здесь будут разные утилиты, которые нельзя отнести к определённому классу"""
